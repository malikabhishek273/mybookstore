<!-- blog promotion starts -->
<div class="row">
  <div class="col-sm-4">
    <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2FThesoftwareguy7&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=198210627014732" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>
    <div class="padding10 clearfix"></div>
  </div>
  <div class="col-sm-4">
    <div class="g-page" data-width="299" data-href="//plus.google.com/115374397759986535215" data-layout="landscape" data-rel="publisher"></div>
    <div class="padding10 clearfix"></div>
    <!-- Place this tag after the last widget tag. -->
    <script type="text/javascript">
      (function() {
        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
        po.src = 'https://apis.google.com/js/platform.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
      })();
    </script>
  </div>
  <div class="col-sm-4">
    <a href="https://twitter.com/thesoftwareguy7" class="twitter-follow-button" data-show-count="true" data-lang="en">Follow @thesoftwareguy7</a>
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
  </div>
</div>
<!-- blog promotion ends -->
</div>

<footer>
  <div class="navbar navbar-inverse footer">
    <div class="container-fluid">
      <div class="copyright">
        <a href="http://www.thesoftwareguy.in" target="_blank">&copy; thesoftwareguy  2013 - <?php echo date("Y"); ?></a> All rights reserved
      </div>
    </div>
  </div>
</footer>


<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$DB = NULL;
?>